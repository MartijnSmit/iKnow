//
//  RootViewController.h
//  iKnow
//
//  Created by Martijn Smit on 23-05-13.
//  Copyright (c) 2013 WeMa IT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RNSwipeViewController.h"

@interface RootViewController : RNSwipeViewController
<RNSwipeViewControllerDelegate>

@end
