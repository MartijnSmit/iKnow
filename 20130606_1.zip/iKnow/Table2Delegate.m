//
//  Table2Delegate.m
//  iKnow
//
//  Created by Martijn Smit on 07-05-13.
//  Copyright (c) 2013 WeMa IT. All rights reserved.
//


#import "Table2Delegate.h"

@implementation Table2Delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    //NSString *text = @"go fuck yourself";
    // = [[cell textLabel] text];
    
    //[[[UIAlertView alloc] initWithTitle:@"Table 2 item selected" message:text delegate:nil cancelButtonTitle:@"Close" otherButtonTitles:nil] show];*/
}

@end
