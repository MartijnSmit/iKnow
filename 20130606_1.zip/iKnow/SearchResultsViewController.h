//
//  SearchResultsViewController.h
//  iKnow
//
//  Created by Martijn Smit on 03-06-13.
//  Copyright (c) 2013 WeMa IT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchResultsViewController : UIViewController

- (IBAction)goBack:(id)sender;
- (IBAction)goProfile:(id)sender;

@end
